from gpt4all import GPT4All

MODEL_PATH = r"C:\Users\alber\AppData\Local\nomic.ai\GPT4All\Nous-Hermes-2-Mistral-7B-DPO.Q4_0.gguf"

def generate_response(question, context):
    model = GPT4All(MODEL_PATH, device='cpu')  # Força CPU
    prompt = f"""Responda de forma curta baseado no contexto:
                Pergunta: {question}
                Contexto: {context}"""
    return model.generate(prompt, max_tokens=100)