from bson import ObjectId
from datetime import timedelta

# ObjectId fornecido
object_id_str = "67feb0d9fc3dca880f4b599c"

# Convertendo o ObjectId em um objeto BSON
object_id = ObjectId(object_id_str)

# Obtendo o timestamp de inserção (em UTC)
timestamp = object_id.generation_time

# Ajustando para o fuso horário de Brasília (subtraindo 3 horas)
local_timestamp = timestamp - timedelta(hours=3)

# Convertendo para formato legível
local_timestamp_str = local_timestamp.strftime("%Y-%m-%d %H:%M:%S")

print(local_timestamp_str)
