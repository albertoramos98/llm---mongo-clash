from pymongo import MongoClient

# Conexão global (ajuste a URI!)
client = MongoClient("mongodb+srv://admin:admin@cluster0.chxornv.mongodb.net/")
db = client["clashroyale"]
battles_collection = db["battles"]

def get_recent_battles(limit=3):
    """Retorna as últimas batalhas formatadas."""
    battles = list(battles_collection.find().sort("battle_time", -1).limit(limit))
    return [
        f"Jogador: {b['player_name']} | Deck: {', '.join(b['player_deck'])} | Resultado: {b['victory']}"
        for b in battles
    ]