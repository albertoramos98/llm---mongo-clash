from flask import Flask, render_template, request
from gpt4all import GPT4All
from pymongo import MongoClient
from datetime import datetime
import os
from dotenv import load_dotenv
from analytics import (
    win_rate_by_card,
    top_decks_by_win_rate,
    defeats_with_combo,
    wins_with_conditions,
    combos_with_high_winrate
)

from analytics import consulta1, consulta2
# Carrega variáveis de ambiente
load_dotenv()

app = Flask(__name__)

# Configurações do MongoDB
MONGO_URI = os.getenv("MONGO_URI", "mongodb+srv://admin:admin@cluster0.chxornv.mongodb.net/")
client = MongoClient(MONGO_URI)
db = client["clashroyale"]
battles_collection = db["battles"]

# Configuração do GPT4All
MODEL_PATH = os.getenv("MODEL_PATH", r"C:\Users\alber\AppData\Local\nomic.ai\GPT4All\Nous-Hermes-2-Mistral-7B-DPO.Q4_0.gguf")

def generate_response(question, context):
    """Gera resposta usando modelo local GPT4All"""
    model = GPT4All(MODEL_PATH, device='cpu')
    prompt = (
        f"Como especialista em Clash Royale, analise estas batalhas:\n"
        f"{context}\n\n"
        f"Pergunta: {question}\n"
        f"Resposta objetiva (máximo 3 frases):"
    )
    return model.generate(prompt, max_tokens=150)

def get_formatted_battles(limit=5):
    """Recupera batalhas formatadas do MongoDB"""
    battles = list(battles_collection.find().sort("battle_time", -1).limit(limit))
    
    # Converte ObjectId e formata dados
    for battle in battles:
        battle["_id"] = str(battle["_id"])
        if isinstance(battle["battle_time"], str):
            battle["battle_time"] = datetime.strptime(battle["battle_time"], "%Y-%m-%d %H:%M:%S")
    
    return battles

@app.route("/", methods=["GET", "POST"])
def index():
    answer = None
    battles = get_formatted_battles()
    
    if request.method == "POST":
        question = request.form.get("question")
        
        # Prepara contexto para a IA
        context = "\n".join(
            f"Batalha {idx+1}: {b['player_name']} (Troféus: {b['player_trophies_after']}) "
            f"vs {b['opponent_name']} | "
            f"Resultado: {b['victory']} | "
            f"Cartas: {', '.join(b['player_deck'])}"
            for idx, b in enumerate(battles)
        )
        
        answer = generate_response(question, context)
    
    return render_template("index.html", answer=answer, battles=battles)

@app.route("/analytics")
def analytics():
    # Exemplo: Vitórias com "Mega Cavaleiro" nos últimos 7 dias
    card_stats = win_rate_by_card(
        "Mega Cavaleiro",
        datetime(2025, 4, 1),
        datetime(2025, 4, 8)
    )
    
    # Exemplo: Decks com >70% de vitórias
    top_decks = top_decks_by_win_rate(
        70,
        datetime(2025, 4, 1),
        datetime(2025, 4, 8)
    )
    
    return render_template("analytics.html", card_stats=card_stats, top_decks=top_decks)

if __name__ == "__main__":
    app.run(debug=True, port=5000)