const axios = require('axios');
const { MongoClient } = require('mongodb');

// Substitua pela sua API Key do Clash Royale
const API_KEY = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiIsImtpZCI6IjI4YTMxOGY3LTAwMDAtYTFlYi03ZmExLTJjNzQzM2M2Y2NhNSJ9.eyJpc3MiOiJzdXBlcmNlbGwiLCJhdWQiOiJzdXBlcmNlbGw6Z2FtZWFwaSIsImp0aSI6ImJjOGE2YjYzLTZlMmEtNGI2Ni05MzkzLTU4YTM1NTI3ZDdkOSIsImlhdCI6MTc0NTQ1NzI4Miwic3ViIjoiZGV2ZWxvcGVyLzI1MzI3OGY4LTgzZWQtZjBhOC0yZGFmLWUwZTM5ZjRhYmQ4ZSIsInNjb3BlcyI6WyJyb3lhbGUiXSwibGltaXRzIjpbeyJ0aWVyIjoiZGV2ZWxvcGVyL3NpbHZlciIsInR5cGUiOiJ0aHJvdHRsaW5nIn0seyJjaWRycyI6WyIxNzcuMTAwLjc0LjE3NyJdLCJ0eXBlIjoiY2xpZW50In1dfQ.2L0jtN9fql9EeUcb36kC-BYwBz94esOfc3rEEBf5hw-m65735DAiy699e_UAjfs7YNRb-y-tYhfJ2W8OJtFliQ"

const API_URL = 'https://api.clashroyale.com/v1/cards'; // Endpoint para obter cartas

// Conexão com o MongoDB (substitua a URI se necessário, como no MongoDB Atlas)
const uri = 'mongodb+srv://admin:admin@cluster0.chxornv.mongodb.net/';
const client = new MongoClient(uri);

async function fetchCards() {
  try {
    const response = await axios.get(API_URL, {
      headers: {
        'Authorization': `Bearer ${API_KEY}`
      }
    });
    return response.data;
  } catch (error) {
    console.error('Erro ao buscar dados da API:', error.response ? error.response.data : error.message);
    return null;
  }
}

async function insertCards(cards) {
  try {
    await client.connect();
    const database = client.db('clash_royale');
    const cartasCollection = database.collection('cartas');
    
    // Combina os arrays "items" e "supportItems"
    let todasCartas = [];
    if (cards && cards.items) {
      todasCartas = todasCartas.concat(cards.items);
    }
    if (cards && cards.supportItems) {
      todasCartas = todasCartas.concat(cards.supportItems);
    }
    
    if (todasCartas.length > 0) {
      const result = await cartasCollection.insertMany(todasCartas);
      console.log(`${result.insertedCount} cartas inseridas com sucesso.`);
    } else {
      console.log('Nenhuma carta encontrada para inserir.');
    }
  } catch (error) {
    console.error('Erro ao inserir dados no MongoDB:', error);
  } finally {
    await client.close();
  }
}

async function main() {
  const cards = await fetchCards();
  if (cards) {
    console.log('Dados obtidos da API:', cards);
    await insertCards(cards);
  }
}

main();
