import requests
from pymongo import MongoClient
from datetime import datetime
import openai


openai.api_key ="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"  # Substitua pelo seu token válido


API_KEY = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiIsImtpZCI6IjI4YTMxOGY3LTAwMDAtYTFlYi03ZmExLTJjNzQzM2M2Y2NhNSJ9.eyJpc3MiOiJzdXBlcmNlbGwiLCJhdWQiOiJzdXBlcmNlbGw6Z2FtZWFwaSIsImp0aSI6ImVkNTZmM2E0LTQ4ZmEtNGYwYy1hYTI1LWQzOWNkM2Q0MzNiYSIsImlhdCI6MTc0NTM2MTY0Niwic3ViIjoiZGV2ZWxvcGVyLzU2MTM2NjAzLWY2NzUtOWU4YS1mMTcxLTY5MzhhMGM0NTFmNyIsInNjb3BlcyI6WyJyb3lhbGUiXSwibGltaXRzIjpbeyJ0aWVyIjoiZGV2ZWxvcGVyL3NpbHZlciIsInR5cGUiOiJ0aHJvdHRsaW5nIn0seyJjaWRycyI6WyIxNzcuMTkuOTkuNDIiXSwidHlwZSI6ImNsaWVudCJ9XX0.nBg_ymYrU6s4vLlNcGSEwMmlprDgnDn1_ib2Nom9WTxA0aSxFt7QQyf0JMGVQSPNx5dLJPtMdIEjVR1iikqqqQ"  # Substitua pelo seu token válido
PLAYER_TAGS = [
    "%23PPG09CGV", "%23LGLQJYQ2", "%23LRYG90VG", "%23RJUQ8CP2", "%23RCC800", 
    "%238PYC90Y9P", "%23QPGRJ28QR", "%232GVCJ00RY", "%239GGUYU09", "%23UV8UY0JUY",
    "%23YUVPP8RVJ", "%23Q0L9RLV9C"
]
headers = {
    "Authorization": f"Bearer {API_KEY}",
    "Accept": "application/json"
}


client = MongoClient("mongodb://localhost:27017/")
db = client["clashroyale"]
battles_collection = db["battles"]

# Função para obter as batalhas
def get_battles():
    all_battles = []
    for player_tag in PLAYER_TAGS:
        url_battles = f"https://api.clashroyale.com/v1/players/{player_tag.replace('#', '%23')}/battlelog"
        response = requests.get(url_battles, headers=headers)
        
        if response.status_code == 200:
            data = response.json()
            all_battles.extend(data)
        else:
            print(f"Erro ao buscar batalhas para a tag {player_tag}: {response.status_code}")
    
    return all_battles

# Salvar no MongoDB
def save_battles_to_mongo(battles):
    for battle in battles:
        try:
            battle_time = datetime.strptime(battle["battleTime"], "%Y%m%dT%H%M%S.%fZ")
        except Exception as e:
            print(f"Erro ao converter data: {e}")
            battle_time = None

        team = battle["team"][0]
        opponent = battle["opponent"][0]

        battle_data = {
            "battle_time": battle_time,
            "type": battle.get("type", "N/A"),
            "victory": "Vitória" if team.get("crowns", 0) > opponent.get("crowns", 0) else "Derrota",
            "player_name": team.get("name", "N/A"),
            "opponent_name": opponent.get("name", "N/A"),
            "player_tag": team.get("tag", "N/A"),
            "opponent_tag": opponent.get("tag", "N/A"),
            "player_crowns": team.get("crowns", 0),
            "opponent_crowns": opponent.get("crowns", 0),
            "player_trophies_before": team.get("startingTrophies", "N/A"),
            "opponent_trophies_before": opponent.get("startingTrophies", "N/A"),
            "player_trophies_after": team.get("trophyChange", 0) + team.get("startingTrophies", 0),
            "opponent_trophies_after": opponent.get("trophyChange", 0) + opponent.get("startingTrophies", 0),
            "player_deck": [card["name"] for card in team.get("cards", [])],
            "opponent_deck": [card["name"] for card in opponent.get("cards", [])]
        }

        result = battles_collection.insert_one(battle_data)
        insertion_time = result.inserted_id.generation_time
        print(f"Batalha salva: {battle_data['battle_time']} | Inserido em: {insertion_time}")

# Função para interagir com o GPT-3
def ask_gpt3(question, context=None):
    prompt = question
    if context:
        prompt = f"Com base nas batalhas a seguir, responda à pergunta: {question}\n\nBatalhas:\n{context}"

    response = openai.Completion.create(
        model="text-davinci-003",  # ou outro modelo como "gpt-3.5-turbo"
        prompt=prompt,
        max_tokens=150
    )
    return response.choices[0].text.strip()

# Função para gerar o contexto das batalhas
def generate_battle_context():
    battles = list(battles_collection.find({}))
    context = ""
    for battle in battles:
        context += f"\nData: {battle['battle_time']} | Vitória: {battle['victory']} | Jogador: {battle['player_name']} | Oponente: {battle['opponent_name']} | Deck do Jogador: {', '.join(battle['player_deck'])} | Deck do Oponente: {', '.join(battle['opponent_deck'])}"
    return context

# Função principal
def main():
    battles = get_battles()
    if battles:
        save_battles_to_mongo(battles)

    # Pergunta do usuário
    user_question = input("Digite sua pergunta sobre as batalhas: ")

    # Gerar contexto das batalhas armazenadas no MongoDB
    battle_context = generate_battle_context()

    # Consultar o GPT-3
    answer = ask_gpt3(user_question, context=battle_context)

    print(f"Resposta do GPT-3: {answer}")

# Executar
if __name__ == "__main__":
    main()
