from pymongo import MongoClient
from datetime import datetime

client = MongoClient("mongodb+srv://admin:admin@cluster0.chxornv.mongodb.net/")
db = client["clashroyale"]

def consulta1(card_name, start_date, end_date):
    """% de vitórias com uma carta específica"""
    pipeline = [
        {"$match": {
            "battle_time": {"$gte": start_date, "$lte": end_date},
            "$or": [
                {"player_deck": card_name},
                {"opponent_deck": card_name}
            ]
        }},
        {"$addFields": {
            "is_win_with_card": {
                "$cond": [
                    {"$and": [
                        {"$eq": ["$player_deck", card_name]},
                        {"$eq": ["$victory", "Vitória"]}
                    ]},
                    1,
                    {"$cond": [
                        {"$and": [
                            {"$eq": ["$opponent_deck", card_name]},
                            {"$eq": ["$victory", "Derrota"]}
                        ]},
                        1,
                        0
                    ]}
                ]
            }
        }},
        {"$group": {
            "_id": None,
            "total": {"$sum": 1},
            "wins": {"$sum": "$is_win_with_card"}
        }},
        {"$project": {
            "win_rate": {"$multiply": [{"$divide": ["$wins", "$total"]}, 100]},
            "total_battles": "$total"
        }}
    ]
    return list(db.battles.aggregate(pipeline))

def consulta2(min_win_rate, start_date, end_date):
    """Decks com > X% de vitórias"""
    pipeline = [
        {"$match": {
            "battle_time": {"$gte": start_date, "$lte": end_date}
        }},
        {"$group": {
            "_id": "$player_deck",
            "wins": {"$sum": {"$cond": [{"$eq": ["$victory", "Vitória"]}, 1, 0]}},
            "total": {"$sum": 1}
        }},
        {"$addFields": {
            "win_rate": {"$multiply": [{"$divide": ["$wins", "$total"]}, 100]}
        }},
        {"$match": {"win_rate": {"$gte": min_win_rate}}},
        {"$sort": {"win_rate": -1}},
        {"$limit": 10}
    ]
    return list(db.battles.aggregate(pipeline))

def consulta3(combo, start_date, end_date):
    """Quantidade de derrotas com um combo de cartas"""
    pipeline = [
        {"$match": {
            "battle_time": {"$gte": start_date, "$lte": end_date},
            "victory": "Derrota"
        }},
        {"$match": {
            "$expr": {
                "$setIsSubset": [combo, "$player_deck"]
            }
        }},
        {"$count": "total_derrotas"}
    ]
    return list(db.battles.aggregate(pipeline))

def consulta4(card_name, trophy_diff_pct):
    """Vitórias com carta X, menos troféus, duração < 2min, e 2 torres do perdedor"""
    pipeline = [
        {"$match": {
            "victory": "Vitória",
            "battle_duration": {"$lt": 120},  # duração em segundos
            "player_deck": card_name,
            "opponent_towers_destroyed": {"$gte": 2}
        }},
        {"$match": {
            "$expr": {
                "$lte": [
                    {"$subtract": ["$player_trophies", "$opponent_trophies"]},
                    {"$multiply": ["$opponent_trophies", -trophy_diff_pct / 100]}
                ]
            }
        }},
        {"$count": "total_vitorias"}
    ]
    return list(db.battles.aggregate(pipeline))

def consulta5(combo_size, min_win_rate, start_date, end_date):
    """Combos de cartas de tamanho N com mais de Y% de vitórias"""
    pipeline = [
        {"$match": {
            "battle_time": {"$gte": start_date, "$lte": end_date}
        }},
        {"$project": {
            "deck": "$player_deck",
            "victory": 1
        }},
        {"$project": {
            "combos": {"$setUnion": ["$deck", []]},  # garante lista única
            "victory": 1
        }},
        {"$unwind": "$combos"},
        {"$group": {
            "_id": "$combos",
            "wins": {"$sum": {"$cond": [{"$eq": ["$victory", "Vitória"]}, 1, 0]}},
            "total": {"$sum": 1}
        }},
        {"$project": {
            "win_rate": {"$multiply": [{"$divide": ["$wins", "$total"]}, 100]}
        }},
        {"$match": {"win_rate": {"$gte": min_win_rate}}},
        {"$limit": 10}
    ]
    return list(db.battles.aggregate(pipeline))

def consulta6(start_date, end_date):
    """Carta mais frequente em decks com alta taxa de derrota"""
    pipeline = [
        {"$match": {
            "battle_time": {"$gte": start_date, "$lte": end_date},
            "victory": "Derrota"
        }},
        {"$unwind": "$player_deck"},
        {"$group": {
            "_id": "$player_deck",
            "frequencia": {"$sum": 1}
        }},
        {"$sort": {"frequencia": -1}},
        {"$limit": 5}
    ]
    return list(db.battles.aggregate(pipeline))

def consulta7(start_date, end_date):
    """Média de troféus por vitória, agrupado por nível de jogador"""
    pipeline = [
        {"$match": {
            "battle_time": {"$gte": start_date, "$lte": end_date},
            "victory": "Vitória"
        }},
        {"$group": {
            "_id": "$player_level",
            "media_trofeus": {"$avg": "$player_trophies"},
            "quantidade_vitorias": {"$sum": 1}
        }},
        {"$sort": {"_id": 1}}
    ]
    return list(db.battles.aggregate(pipeline))

def consulta8(card_name, min_win_rate, start_date, end_date):
    """
    Compara a win rate de uma carta específica com os decks top tier por win rate.
    Retorna o win rate da carta + decks com win rate acima do limite especificado.
    """
    win_rate_card = consulta1(card_name, start_date, end_date)
    top_decks = consulta2(min_win_rate, start_date, end_date)
    
    return {
        "win_rate_da_carta": win_rate_card,
        "decks_com_mais_de_{}_porcento_de_winrate".format(min_win_rate): top_decks
    }

from pymongo import MongoClient
from datetime import datetime

client = MongoClient("mongodb+srv://admin:admin@cluster0.chxornv.mongodb.net/")
db = client["clashroyale"]

def win_rate_by_card(card_name, start_date, end_date):
    """% de vitórias com uma carta específica"""
    pipeline = [
        {"$match": {
            "battle_time": {"$gte": start_date, "$lte": end_date},
            "$or": [
                {"player_deck": card_name},
                {"opponent_deck": card_name}
            ]
        }},
        {"$addFields": {
            "is_win_with_card": {
                "$cond": [
                    {"$and": [
                        {"$eq": ["$player_deck", card_name]},
                        {"$eq": ["$victory", "Vitória"]}
                    ]},
                    1,
                    {"$cond": [
                        {"$and": [
                            {"$eq": ["$opponent_deck", card_name]},
                            {"$eq": ["$victory", "Derrota"]}
                        ]},
                        1,
                        0
                    ]}
                ]
            }
        }},
        {"$group": {
            "_id": None,
            "total": {"$sum": 1},
            "wins": {"$sum": "$is_win_with_card"}
        }},
        {"$project": {
            "win_rate": {"$multiply": [{"$divide": ["$wins", "$total"]}, 100]},
            "total_battles": "$total"
        }}
    ]
    return list(db.battles.aggregate(pipeline))

def top_decks_by_win_rate(min_win_rate, start_date, end_date):
    """Decks com > X% de vitórias"""
    pipeline = [
        {"$match": {
            "battle_time": {"$gte": start_date, "$lte": end_date}
        }},
        {"$group": {
            "_id": "$player_deck",
            "wins": {"$sum": {"$cond": [{"$eq": ["$victory", "Vitória"]}, 1, 0]}},
            "total": {"$sum": 1}
        }},
        {"$addFields": {
            "win_rate": {"$multiply": [{"$divide": ["$wins", "$total"]}, 100]}
        }},
        {"$match": {"win_rate": {"$gte": min_win_rate}}},
        {"$sort": {"win_rate": -1}},
        {"$limit": 10}
    ]
    return list(db.battles.aggregate(pipeline))

def defeats_with_combo(combo, start_date, end_date):
    """Quantidade de derrotas com um combo de cartas"""
    pipeline = [
        {"$match": {
            "battle_time": {"$gte": start_date, "$lte": end_date},
            "victory": "Derrota"
        }},
        {"$match": {
            "$expr": {
                "$setIsSubset": [combo, "$player_deck"]
            }
        }},
        {"$count": "total_derrotas"}
    ]
    return list(db.battles.aggregate(pipeline))

def wins_with_conditions(card_name, trophy_diff_pct):
    """Vitórias com carta X, menos troféus, duração < 2min, e 2 torres do perdedor"""
    pipeline = [
        {"$match": {
            "victory": "Vitória",
            "battle_duration": {"$lt": 120},
            "player_deck": card_name,
            "opponent_towers_destroyed": {"$gte": 2}
        }},
        {"$match": {
            "$expr": {
                "$lte": [
                    {"$subtract": ["$player_trophies", "$opponent_trophies"]},
                    {"$multiply": ["$opponent_trophies", -trophy_diff_pct / 100]}
                ]
            }
        }},
        {"$count": "total_vitorias"}
    ]
    return list(db.battles.aggregate(pipeline))

def combos_with_high_winrate(combo_size, min_win_rate, start_date, end_date):
    """Combos de tamanho N com mais de Y% de vitórias"""
    # Essa consulta é uma simplificação. Em produção, precisa gerar combinações dos decks
    pipeline = [
        {"$match": {
            "battle_time": {"$gte": start_date, "$lte": end_date}
        }},
        {"$unwind": "$player_deck"},
        {"$group": {
            "_id": "$player_deck",
            "wins": {"$sum": {"$cond": [{"$eq": ["$victory", "Vitória"]}, 1, 0]}},
            "total": {"$sum": 1}
        }},
        {"$addFields": {
            "win_rate": {"$multiply": [{"$divide": ["$wins", "$total"]}, 100]}
        }},
        {"$match": {"win_rate": {"$gte": min_win_rate}}},
        {"$limit": 10}
    ]
    return list(db.battles.aggregate(pipeline))

# (... implemente as outras 3 consultas seguindo o mesmo padrão ...)