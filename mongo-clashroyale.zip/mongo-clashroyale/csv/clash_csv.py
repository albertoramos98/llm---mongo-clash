import csv
import requests
from datetime import datetime
import uuid  # Para gerar um ID único para cada batalha

API_KEY = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiIsImtpZCI6IjI4YTMxOGY3LTAwMDAtYTFlYi03ZmExLTJjNzQzM2M2Y2NhNSJ9.eyJpc3MiOiJzdXBlcmNlbGwiLCJhdWQiOiJzdXBlcmNlbGw6Z2FtZWFwaSIsImp0aSI6ImJjOGE2YjYzLTZlMmEtNGI2Ni05MzkzLTU4YTM1NTI3ZDdkOSIsImlhdCI6MTc0NTQ1NzI4Miwic3ViIjoiZGV2ZWxvcGVyLzI1MzI3OGY4LTgzZWQtZjBhOC0yZGFmLWUwZTM5ZjRhYmQ4ZSIsInNjb3BlcyI6WyJyb3lhbGUiXSwibGltaXRzIjpbeyJ0aWVyIjoiZGV2ZWxvcGVyL3NpbHZlciIsInR5cGUiOiJ0aHJvdHRsaW5nIn0seyJjaWRycyI6WyIxNzcuMTAwLjc0LjE3NyJdLCJ0eXBlIjoiY2xpZW50In1dfQ.2L0jtN9fql9EeUcb36kC-BYwBz94esOfc3rEEBf5hw-m65735DAiy699e_UAjfs7YNRb-y-tYhfJ2W8OJtFliQ"  # Substitua pelo seu token válido

TAGS_JOGADORES = [
    "%23PPG09CGV", "%23LGLQJYQ2", "%23LRYG90VG", "%23RJUQ8CP2", "%23RCC800", 
    "%238PYC90Y9P", "%23QPGRJ28QR", "%232GVCJ00RY", "%239GGUYU09", "%23UV8UY0JUY",
    "%23YUVPP8RVJ", "%23Q0L9RLV9C"
]

cabecalho = {
    "Authorization": f"Bearer {API_KEY}",
    "Accept": "application/json"
}

def buscar_batalhas():
    todas_batalhas = []
    for tag in TAGS_JOGADORES:
        url = f"https://api.clashroyale.com/v1/players/{tag}/battlelog"
        resposta = requests.get(url, headers=cabecalho)

        if resposta.status_code == 200:
            batalhas = resposta.json()
            for batalha in batalhas:
                if "team" in batalha and "opponent" in batalha:
                    time = batalha["team"][0]
                    oponente = batalha["opponent"][0]
                    
                    try:
                        horario_batalha = datetime.strptime(batalha["battleTime"], "%Y%m%dT%H%M%S.%fZ")
                    except:
                        horario_batalha = batalha["battleTime"]

                    vitoria = "Vitória" if time.get("crowns", 0) > oponente.get("crowns", 0) else "Derrota"
                    
                    id_batalha = str(uuid.uuid4())

                    # Cartas do jogador
                    for carta in time.get("cards", []):
                        linha_jogador = {
                            "id_batalha": id_batalha,
                            "horario_batalha": horario_batalha,
                            "nome_jogador": time.get("name", "N/A"),
                            "tag_jogador": time.get("tag", "N/A"),
                            "nome_carta": carta["name"],
                            "tipo_jogador": "jogador",
                            "resultado": vitoria
                        }
                        todas_batalhas.append(linha_jogador)

                    # Cartas do oponente
                    for carta in oponente.get("cards", []):
                        linha_oponente = {
                            "id_batalha": id_batalha,
                            "horario_batalha": horario_batalha,
                            "nome_jogador": oponente.get("name", "N/A"),
                            "tag_jogador": oponente.get("tag", "N/A"),
                            "nome_carta": carta["name"],
                            "tipo_jogador": "oponente",
                            "resultado": "Derrota" if vitoria == "Vitória" else "Vitória"
                        }
                        todas_batalhas.append(linha_oponente)

        else:
            print(f"Erro ao buscar batalhas para {tag}: {resposta.status_code}")
    return todas_batalhas

def exportar_para_csv(batalhas):
    if not batalhas:
        print("Nenhuma batalha encontrada.")
        return

    with open("batalhas_powerbi.csv", "w", newline="", encoding="utf-8") as f:
        escritor = csv.DictWriter(f, fieldnames=["id_batalha", "horario_batalha", "nome_jogador", "tag_jogador", "nome_carta", "tipo_joagdor", "resultado"])
        escritor.writeheader()
        escritor.writerows(batalhas)
    print("CSV gerado com sucesso como 'batalhas_powerbi.csv'.")

# Executar
batalhas = buscar_batalhas()
exportar_para_csv(batalhas)
