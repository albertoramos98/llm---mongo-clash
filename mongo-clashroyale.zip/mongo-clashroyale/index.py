import requests
from pymongo import MongoClient
from datetime import datetime

# Configuração da API
API_KEY = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiIsImtpZCI6IjI4YTMxOGY3LTAwMDAtYTFlYi03ZmExLTJjNzQzM2M2Y2NhNSJ9.eyJpc3MiOiJzdXBlcmNlbGwiLCJhdWQiOiJzdXBlcmNlbGw6Z2FtZWFwaSIsImp0aSI6ImJjOGE2YjYzLTZlMmEtNGI2Ni05MzkzLTU4YTM1NTI3ZDdkOSIsImlhdCI6MTc0NTQ1NzI4Miwic3ViIjoiZGV2ZWxvcGVyLzI1MzI3OGY4LTgzZWQtZjBhOC0yZGFmLWUwZTM5ZjRhYmQ4ZSIsInNjb3BlcyI6WyJyb3lhbGUiXSwibGltaXRzIjpbeyJ0aWVyIjoiZGV2ZWxvcGVyL3NpbHZlciIsInR5cGUiOiJ0aHJvdHRsaW5nIn0seyJjaWRycyI6WyIxNzcuMTAwLjc0LjE3NyJdLCJ0eXBlIjoiY2xpZW50In1dfQ.2L0jtN9fql9EeUcb36kC-BYwBz94esOfc3rEEBf5hw-m65735DAiy699e_UAjfs7YNRb-y-tYhfJ2W8OJtFliQ"  # Substitua pelo seu token válido

PLAYER_TAGS = [
    "%23PPG09CGV", "%23LGLQJYQ2", "%23LRYG90VG", "%23RJUQ8CP2", "%23RCC800", 
    "%238PYC90Y9P", "%23QPGRJ28QR", "%232GVCJ00RY", "%239GGUYU09", "%23UV8UY0JUY",
    "%23YUVPP8RVJ", "%23Q0L9RLV9C"
]
headers = {
    "Authorization": f"Bearer {API_KEY}",
    "Accept": "application/json"
}

# Conectar ao MongoDB
client = MongoClient("mongodb+srv://admin:admin@cluster0.chxornv.mongodb.net/")
db = client["clashroyale"]
battles_collection = db["battles"]

# Função para obter as batalhas
def get_battles():
    all_battles = []
    for player_tag in PLAYER_TAGS:
        url_battles = f"https://api.clashroyale.com/v1/players/{player_tag.replace('#', '%23')}/battlelog"
        response = requests.get(url_battles, headers=headers)
        
        if response.status_code == 200:
            data = response.json()
            all_battles.extend(data)
        else:
            print(f"Erro ao buscar batalhas para a tag {player_tag}: {response.status_code}")
    
    return all_battles

# Salvar no MongoDB
def save_battles_to_mongo(battles):
    for battle in battles:
        try:
            battle_time = datetime.strptime(battle["battleTime"], "%Y%m%dT%H%M%S.%fZ")
        except Exception as e:
            print(f"Erro ao converter data: {e}")
            battle_time = None

        team = battle["team"][0]
        opponent = battle["opponent"][0]

        battle_data = {
            "battle_time": battle_time,
            "type": battle.get("type", "N/A"),
            "victory": "Vitória" if team.get("crowns", 0) > opponent.get("crowns", 0) else "Derrota",
            "player_name": team.get("name", "N/A"),
            "opponent_name": opponent.get("name", "N/A"),
            "player_tag": team.get("tag", "N/A"),
            "opponent_tag": opponent.get("tag", "N/A"),
            "player_crowns": team.get("crowns", 0),
            "opponent_crowns": opponent.get("crowns", 0),
            "player_trophies_before": team.get("startingTrophies", "N/A"),
            "opponent_trophies_before": opponent.get("startingTrophies", "N/A"),
            "player_trophies_after": team.get("trophyChange", 0) + team.get("startingTrophies", 0),
            "opponent_trophies_after": opponent.get("trophyChange", 0) + opponent.get("startingTrophies", 0),
            "player_deck": [card["name"] for card in team.get("cards", [])],
            "opponent_deck": [card["name"] for card in opponent.get("cards", [])]
        }

        result = battles_collection.insert_one(battle_data)
        insertion_time = result.inserted_id.generation_time
        print(f"Batalha salva: {battle_data['battle_time']} | Inserido em: {insertion_time}")

# Executar
battles = get_battles()
if battles:
    save_battles_to_mongo(battles)
else:
    print("Nenhuma batalha encontrada.")
